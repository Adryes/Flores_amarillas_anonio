# buttoncheckosito
👋 Hola, soy @mabelolivera10 "MABEL QUISPE OLIVERA"
👀 Persona apasionada con su profesión, excelente capacidad de organización y facilidad de trabajo en equipo. Muy adaptable a todo tipo de entornos y clara orientación a objetivos. Con conocimientos en diferentes lenguajes de programación como: Java, Visual.NET, PHP, entre otros; Interés en el área de desarrollo de software y/o Análisis de sistemas.
🌱 Actualmente estoy aprendiendo distintos lenguajes de programación
💞️ Busco colaborar contigo
📫 Cómo contactarme en mis redes sociales:
Facebook: https://www.facebook.com/mabelquispeolivera/
Instagram: https://www.instagram.com/mabelolivera10/
TikTok: https://www.tiktok.com/@encodedmabel
Youtube: https://www.youtube.com/@encodedmabel
Linkedin: https://www.linkedin.com/in/mabelquispeolivera/
Twitter: https://twitter.com/mabel_Q_O
CodeOpen: https://codepen.io/mabelolivera10
web: https://encoded.pe/
